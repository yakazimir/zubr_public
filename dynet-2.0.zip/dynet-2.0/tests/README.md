Use `test-dynet.cc` as a reference for how to set up subsequent tests.
