#ifndef DYNET_GRAPH_H
#define DYNET_GRAPH_H

namespace dynet {
struct ComputationGraph;
void graph_optimize(ComputationGraph* cg);
} // namespace dynet

#endif
