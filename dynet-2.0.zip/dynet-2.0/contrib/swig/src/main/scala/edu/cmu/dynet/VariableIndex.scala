package edu.cmu.dynet

/* You shouldn't need to use this. */
private[dynet] class VariableIndex(private[dynet] val index: internal.SWIGTYPE_p_dynet__VariableIndex) {}