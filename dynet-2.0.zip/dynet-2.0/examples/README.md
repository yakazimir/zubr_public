# Examples for Dynet

This is a set of common (and less common) models and their implementation in Dynet (C++ and python).

For now most examples don't have an implementation in both languages but we're working on it
