// Platform-independent header to allow calls to getpid()
// 
#if _WINDOWS
    #include <process.h>
#endif
#include <unistd.h>
