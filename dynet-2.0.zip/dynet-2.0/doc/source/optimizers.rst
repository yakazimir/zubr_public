Optimizers
----------

The various optimizers that you can use to tune your parameters

.. doxygengroup:: optimizers
	:members:
	:content-only:
