Builders
--------

Builders combine together various operations to implement more
complicated things such as recurrent and LSTM networks

.. doxygengroup:: rnnbuilders
	:members:
	:content-only:
