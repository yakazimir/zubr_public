C++ Reference manual
===================

.. toctree::
   :maxdepth: 2
   
   core
   operations
   builders
   optimizers